# Contrato do WMS legado

Base local: `http://127.0.0.1:3000`. JSON de entrada e saída. Todas as rotas `/api/v1` exigem `Authorization: Bearer <token>`, exceto a criação de sessão. CORS permite a origem definida no `.env`.

| Método | Rota | Entrada ou resultado |
| --- | --- | --- |
| GET | `/health` | Disponibilidade HTTP e MySQL |
| POST | `/api/v1/sessao` | `{ "codigo": "OP001", "pin": "1234" }`; devolve token, expiração e operador |
| DELETE | `/api/v1/sessao` | Encerra sessão; HTTP 204 |
| GET | `/api/v1/paletes/PAL-001` | Palete, lote, SKU, descrição, validade, quantidade, situação e endereço |
| GET | `/api/v1/enderecos` | Lista com código, capacidade, ativo e ocupados |
| GET | `/api/v1/enderecos/A-01-01/estoque` | Endereço e lista de paletes ativos |
| POST | `/api/v1/movimentos` | Transferência ou baixa; HTTP 201 e `{ "id": 1, "reaplicado": false }` |
| GET | `/api/v1/movimentos` | Até 100 registros visíveis ao perfil, mais recentes primeiro |

Transferência: `{ "cod_pal": "PAL-001", "tip_mov": "T", "end_dest": "A-01-02" }`.

Baixa: `{ "cod_pal": "PAL-003", "tip_mov": "B", "motivo": "Produto vencido" }`. Exige supervisor.

Movimentos exigem cabeçalho `Idempotency-Key` com identificador único por intenção de operação, até 64 letras, números, `_` ou `-`. Gere com `crypto.randomUUID()` no cliente e preserve a chave e o corpo ao reenviar após uma falha. Repetir a mesma operação com a mesma chave retorna HTTP 200 com o mesmo ID e `reaplicado: false`, sem nova movimentação. Reutilizar a chave com corpo diferente retorna `409 REQ_CONFLITO`. O escopo da chave é o operador autenticado; sincronize com o mesmo operador. Nova operação exige nova chave.

Erros: `{ "codigo": "END_LOTADO", "mensagem": "Destino sem capacidade." }`. HTTP 400 para JSON inválido; 401 para sessão ou credenciais inválidas; 403 para falta de permissão; 404 para registro ou rota inexistente; 409 para chave conflitante ou concorrência; 413 para corpo acima de 16 KB; 422 para dados ou regra de negócio; 429 para limite de login; 503 para indisponibilidade. Erros 422 exigem revisão da operação. Em `TENTE_NOVAMENTE` ou resposta perdida, reenvie a mesma intenção com a mesma chave; não crie uma nova chave automaticamente.

O endpoint de login aceita dez tentativas por IP por minuto, com contador em memória. Não há rotas de cadastro ou edição de regras. O contrato é descrito aqui em Markdown e no arquivo HTTP, sem Swagger nesta versão mínima.
