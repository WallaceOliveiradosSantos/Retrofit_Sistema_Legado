import test from 'node:test';
import assert from 'node:assert/strict';
import { validateMovement } from '../src/rules.js';
import { hashPin, verifyPin } from '../src/security.js';
const pallet = { situacao: 'ATIVO', endereco_id: 1, validade: '2026-12-01' };
const dest = { id: 2, ativo: 1, capacidade: 2, ocupados: 1 };
const check = (p, d, type = 'T') => validateMovement(p, d, type, '2026-10-21');
test('transferência válida e validade no dia são aceitas', () => {
  assert.doesNotThrow(() => check(pallet, dest));
  assert.doesNotThrow(() => check({ ...pallet, validade: '2026-10-21' }, dest));
});
for (const [name, p, d, code] of [
  ['palete baixado', { ...pallet, situacao: 'BAIXADO' }, dest, 'PAL_INATIVO'],
  ['lote vencido', { ...pallet, validade: '2026-10-20' }, dest, 'LOT_VENCIDO'],
  ['destino inexistente', pallet, null, 'END_INVALIDO'],
  ['destino inativo', pallet, { ...dest, ativo: 0 }, 'END_INVALIDO'],
  ['mesma origem', pallet, { ...dest, id: 1 }, 'END_IGUAL'],
  ['capacidade excedida', pallet, { ...dest, ocupados: 2 }, 'END_LOTADO']
]) test(name, () => assert.throws(() => check(p, d), { code }));
test('baixa de vencido é permitida pela regra de domínio', () => assert.doesNotThrow(() => check({ ...pallet, validade: '2026-01-01' }, null, 'B')));
test('PIN é protegido com salt e validação', () => {
  const hash = hashPin('1234');
  assert.equal(verifyPin('1234', hash), true);
  assert.equal(verifyPin('9999', hash), false);
  assert.notEqual(hashPin('1234'), hash);
});
