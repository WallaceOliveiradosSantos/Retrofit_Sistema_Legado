import express from 'express';
import cors from 'cors';
import { createHash } from 'node:crypto';
import { pool } from './db.js';
import { config } from './config.js';
import { verifyPin, tokenHash, newToken } from './security.js';
import { BusinessError, validateMovement } from './rules.js';

export const app = express();
app.disable('x-powered-by');
app.use(cors({ origin: config.origin }));
app.use(express.json({ limit: '16kb' }));
const fail = (code, message, status = 422) => { throw new BusinessError(code, message, status); };
const text = (value, max = 30) => typeof value === 'string' && value.trim().length > 0 && value.length <= max;

app.get('/health', async (req, res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', sistema: 'WMS-LEGADO', versao: '1.0' });
});

// Limitação simples em memória, suficiente para uma única instância de laboratório.
const attempts = new Map();
const cleanup = setInterval(() => {
  for (const [key, value] of attempts) if (Date.now() > value.until) attempts.delete(key);
}, 60000);
cleanup.unref();
app.post('/api/v1/sessao', async (req, res) => {
  const key = req.ip;
  const now = Date.now();
  let entry = attempts.get(key);
  if (!entry || now > entry.until) entry = { count: 0, until: now + 60000 };
  attempts.set(key, entry);
  if (++entry.count > 10) fail('LOGIN_LIMITE', 'Aguarde um minuto para tentar novamente.', 429);
  const { codigo, pin } = req.body || {};
  if (!text(codigo, 20) || !/^\d{4}$/.test(String(pin))) fail('LOGIN_INVALIDO', 'Credenciais inválidas.', 401);
  const [[operator]] = await pool.execute('SELECT * FROM operadores WHERE codigo=? AND ativo=1', [codigo]);
  if (!operator || !verifyPin(String(pin), operator.pin_hash)) fail('LOGIN_INVALIDO', 'Credenciais inválidas.', 401);
  const token = newToken();
  const expiry = new Date(Date.now() + config.sessionHours * 3600000);
  await pool.execute('INSERT INTO sessoes (token_hash,operador_id,expira_em) VALUES (?,?,?)', [tokenHash(token), operator.id, expiry]);
  res.json({ token, expira_em: expiry.toISOString(), operador: { codigo, nome: operator.nome, perfil: operator.perfil } });
});

app.use('/api/v1', async (req, res, next) => {
  const token = req.headers.authorization?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
  if (!token) fail('SESSAO_INVALIDA', 'Informe Bearer token.', 401);
  const [[operator]] = await pool.execute('SELECT o.id,o.codigo,o.perfil FROM sessoes s JOIN operadores o ON o.id=s.operador_id WHERE s.token_hash=? AND s.expira_em>UTC_TIMESTAMP() AND o.ativo=1', [tokenHash(token)]);
  if (!operator) fail('SESSAO_INVALIDA', 'Sessão inválida ou expirada.', 401);
  req.operator = operator;
  req.token = token;
  next();
});
app.delete('/api/v1/sessao', async (req, res) => {
  await pool.execute('DELETE FROM sessoes WHERE token_hash=?', [tokenHash(req.token)]);
  res.status(204).end();
});
const palletSelect = `SELECT p.codigo AS palete,p.quantidade,p.situacao,l.codigo AS lote,
  DATE_FORMAT(l.validade,'%Y-%m-%d') AS validade,pr.sku,pr.descricao,e.codigo AS endereco
  FROM paletes p JOIN lotes l ON l.id=p.lote_id JOIN produtos pr ON pr.id=l.produto_id
  JOIN enderecos e ON e.id=p.endereco_id`;
app.get('/api/v1/paletes/:codigo', async (req, res) => {
  const [[row]] = await pool.execute(`${palletSelect} WHERE p.codigo=?`, [req.params.codigo]);
  if (!row) fail('PAL_NAO_ENCONTRADO', 'Palete não encontrado.', 404);
  res.json(row);
});
app.get('/api/v1/enderecos', async (req, res) => {
  const [rows] = await pool.query("SELECT e.codigo,e.capacidade,e.ativo,COUNT(p.id) AS ocupados FROM enderecos e LEFT JOIN paletes p ON p.endereco_id=e.id AND p.situacao='ATIVO' GROUP BY e.id ORDER BY e.codigo");
  res.json(rows);
});
app.get('/api/v1/enderecos/:codigo/estoque', async (req, res) => {
  const [[address]] = await pool.execute('SELECT codigo FROM enderecos WHERE codigo=?', [req.params.codigo]);
  if (!address) fail('END_NAO_ENCONTRADO', 'Endereço não encontrado.', 404);
  const [rows] = await pool.execute(`${palletSelect} WHERE e.codigo=? AND p.situacao='ATIVO' ORDER BY p.codigo`, [req.params.codigo]);
  res.json({ endereco: address.codigo, paletes: rows });
});

app.post('/api/v1/movimentos', async (req, res) => {
  const { cod_pal, tip_mov, end_dest = null, motivo = null } = req.body || {};
  const requestId = req.get('Idempotency-Key');
  if (!text(requestId, 64) || !/^[\w-]+$/.test(requestId)) fail('REQ_INVALIDA', 'Informe Idempotency-Key (até 64 letras, números, _ ou -).');
  if (!text(cod_pal) || !['T', 'B'].includes(tip_mov)) fail('MOV_INVALIDO', 'Informe cod_pal e tip_mov T ou B.');
  if (tip_mov === 'T' && (!text(end_dest) || motivo !== null)) fail('MOV_INVALIDO', 'Transferência exige end_dest e não utiliza motivo.');
  if (tip_mov === 'B' && (!text(motivo, 200) || end_dest !== null)) fail('MOV_INVALIDO', 'Baixa exige motivo e não utiliza end_dest.');
  if (tip_mov === 'B' && req.operator.perfil !== 'SUPERVISOR') fail('SEM_PERMISSAO', 'Baixa exige supervisor.', 403);
  const hash = createHash('sha256').update(JSON.stringify([cod_pal, tip_mov, end_dest, motivo])).digest('hex');
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    // Serializa operações do mesmo operador, incluindo reenvios concorrentes.
    await conn.execute('SELECT id FROM operadores WHERE id=? FOR UPDATE', [req.operator.id]);
    const [[existing]] = await conn.execute('SELECT id,payload_hash FROM movimentos WHERE operador_id=? AND requisicao_id=?', [req.operator.id, requestId]);
    if (existing) {
      if (existing.payload_hash !== hash) fail('REQ_CONFLITO', 'Chave já utilizada com outros dados.', 409);
      await conn.commit();
      return res.json({ id: existing.id, reaplicado: false });
    }
    const [[pallet]] = await conn.execute('SELECT p.*,DATE_FORMAT(l.validade,\'%Y-%m-%d\') AS validade FROM paletes p JOIN lotes l ON l.id=p.lote_id WHERE p.codigo=? FOR UPDATE', [cod_pal]);
    if (!pallet) fail('PAL_NAO_ENCONTRADO', 'Palete não encontrado.', 404);
    let destination;
    if (tip_mov === 'T') {
      [[destination]] = await conn.execute('SELECT * FROM enderecos WHERE codigo=? FOR UPDATE', [end_dest]);
      if (destination) {
        // Leitura com bloqueio vê o estado confirmado mais recente, mesmo no REPEATABLE READ.
        const [occupied] = await conn.execute("SELECT id FROM paletes WHERE endereco_id=? AND situacao='ATIVO' FOR UPDATE", [destination.id]);
        destination.ocupados = occupied.length;
      }
    }
    validateMovement(pallet, destination, tip_mov, new Date().toISOString().slice(0, 10));
    const [result] = await conn.execute('INSERT INTO movimentos (requisicao_id,operador_id,palete_id,tipo,origem_id,destino_id,quantidade,motivo,payload_hash) VALUES (?,?,?,?,?,?,?,?,?)',
      [requestId, req.operator.id, pallet.id, tip_mov, pallet.endereco_id, destination?.id ?? null, pallet.quantidade, motivo, hash]);
    if (tip_mov === 'T') await conn.execute('UPDATE paletes SET endereco_id=? WHERE id=?', [destination.id, pallet.id]);
    else await conn.execute("UPDATE paletes SET situacao='BAIXADO',quantidade=0 WHERE id=?", [pallet.id]);
    await conn.commit();
    res.status(201).json({ id: result.insertId, reaplicado: false });
  } catch (error) {
    await conn.rollback();
    if (['ER_LOCK_DEADLOCK', 'ER_LOCK_WAIT_TIMEOUT'].includes(error.code)) throw new BusinessError('TENTE_NOVAMENTE', 'Concorrência detectada. Reenvie com a mesma chave.', 409);
    throw error;
  } finally { conn.release(); }
});
app.get('/api/v1/movimentos', async (req, res) => {
  const [rows] = await pool.execute(`SELECT m.id,m.tipo,p.codigo AS palete,o.codigo AS operador,
    e.codigo AS origem,d.codigo AS destino,m.quantidade,m.motivo,m.criado_em
    FROM movimentos m JOIN paletes p ON p.id=m.palete_id JOIN operadores o ON o.id=m.operador_id
    JOIN enderecos e ON e.id=m.origem_id LEFT JOIN enderecos d ON d.id=m.destino_id
    WHERE (?='SUPERVISOR' OR m.operador_id=?) ORDER BY m.id DESC LIMIT 100`, [req.operator.perfil, req.operator.id]);
  res.json(rows);
});
app.use((req, res) => res.status(404).json({ codigo: 'ROTA_INEXISTENTE', mensagem: 'Rota não encontrada.' }));
app.use((error, req, res, next) => {
  if (error instanceof BusinessError) return res.status(error.status).json({ codigo: error.code, mensagem: error.message });
  if (error.type === 'entity.parse.failed') return res.status(400).json({ codigo: 'JSON_INVALIDO', mensagem: 'JSON inválido.' });
  if (error.type === 'entity.too.large') return res.status(413).json({ codigo: 'CORPO_EXCESSIVO', mensagem: 'Limite de 16 KB.' });
  console.error(JSON.stringify({ evento: 'erro_backend', codigo: error.code || 'INTERNO' }));
  res.status(503).json({ codigo: 'INDISPONIVEL', mensagem: 'Serviço indisponível. Tente novamente.' });
});
