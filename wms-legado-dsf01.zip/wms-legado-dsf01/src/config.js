export const config = {
  port: Number(process.env.PORT || 3000),
  origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
  sessionHours: Number(process.env.SESSION_HOURS || 8),
  database: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'wms',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'wms_legado',
    timezone: 'Z',
    waitForConnections: true,
    connectionLimit: 10,
    decimalNumbers: true
  }
};
