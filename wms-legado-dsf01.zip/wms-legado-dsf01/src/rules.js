export class BusinessError extends Error {
  constructor(code, message, status = 422) {
    super(message);
    this.code = code;
    this.status = status;
  }
}
export function validateMovement(pallet, destination, type, today) {
  if (pallet.situacao !== 'ATIVO') throw new BusinessError('PAL_INATIVO', 'Palete indisponível.');
  if (type === 'T') {
    if (pallet.validade < today) throw new BusinessError('LOT_VENCIDO', 'Lote vencido: solicite baixa ao supervisor.');
    if (!destination || !destination.ativo) throw new BusinessError('END_INVALIDO', 'Destino indisponível.');
    if (destination.id === pallet.endereco_id) throw new BusinessError('END_IGUAL', 'Origem e destino iguais.');
    if (Number(destination.ocupados) >= destination.capacidade) throw new BusinessError('END_LOTADO', 'Destino sem capacidade.');
  }
}
