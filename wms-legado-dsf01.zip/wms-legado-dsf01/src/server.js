import { app } from './app.js';
import { pool } from './db.js';
import { config } from './config.js';
await pool.query('SELECT 1');
const server = app.listen(config.port, '127.0.0.1', () => console.log(`WMS legado em http://127.0.0.1:${config.port}`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
  server.close(async () => { await pool.end(); process.exit(0); });
});
