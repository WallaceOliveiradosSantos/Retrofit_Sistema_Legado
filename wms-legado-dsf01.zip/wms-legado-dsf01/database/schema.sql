CREATE TABLE operadores (
  id INT PRIMARY KEY AUTO_INCREMENT,
  codigo VARCHAR(20) UNIQUE NOT NULL,
  nome VARCHAR(80) NOT NULL,
  pin_hash VARCHAR(180) NOT NULL,
  perfil ENUM('OPERADOR','SUPERVISOR') NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE sessoes (
  token_hash CHAR(64) PRIMARY KEY,
  operador_id INT NOT NULL,
  expira_em DATETIME NOT NULL,
  FOREIGN KEY (operador_id) REFERENCES operadores(id)
);
CREATE TABLE produtos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sku VARCHAR(30) UNIQUE NOT NULL,
  descricao VARCHAR(120) NOT NULL
);
CREATE TABLE lotes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  produto_id INT NOT NULL,
  validade DATE NOT NULL,
  FOREIGN KEY (produto_id) REFERENCES produtos(id)
);
CREATE TABLE enderecos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  capacidade INT NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  CHECK (capacidade > 0)
);
CREATE TABLE paletes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  codigo VARCHAR(30) UNIQUE NOT NULL,
  lote_id INT NOT NULL,
  endereco_id INT NOT NULL,
  quantidade INT NOT NULL,
  situacao ENUM('ATIVO','BAIXADO') NOT NULL DEFAULT 'ATIVO',
  FOREIGN KEY (lote_id) REFERENCES lotes(id),
  FOREIGN KEY (endereco_id) REFERENCES enderecos(id),
  INDEX idx_paletes_endereco (endereco_id, situacao),
  CHECK (quantidade >= 0)
);
CREATE TABLE movimentos (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  requisicao_id VARCHAR(64) NOT NULL,
  operador_id INT NOT NULL,
  palete_id INT NOT NULL,
  tipo ENUM('T','B') NOT NULL,
  origem_id INT NOT NULL,
  destino_id INT,
  quantidade INT NOT NULL,
  motivo VARCHAR(200),
  payload_hash CHAR(64) NOT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_requisicao (operador_id, requisicao_id),
  FOREIGN KEY (operador_id) REFERENCES operadores(id),
  FOREIGN KEY (palete_id) REFERENCES paletes(id),
  FOREIGN KEY (origem_id) REFERENCES enderecos(id),
  FOREIGN KEY (destino_id) REFERENCES enderecos(id)
);
