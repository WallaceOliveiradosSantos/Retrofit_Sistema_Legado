import { readFile } from 'node:fs/promises';
import { pool } from '../src/db.js';
import { hashPin } from '../src/security.js';

if (!process.argv.includes('--confirmar')) {
  console.error('Este comando apaga os dados didáticos. Execute npm run db:reset -- --confirmar');
  process.exitCode = 1;
} else {
  const connection = await pool.getConnection();
  try {
    for (const table of ['movimentos', 'sessoes', 'paletes', 'lotes', 'enderecos', 'produtos', 'operadores']) {
      await connection.query(`DROP TABLE IF EXISTS ${table}`);
    }
    const schema = await readFile(new URL('../database/schema.sql', import.meta.url), 'utf8');
    for (const sql of schema.split(';').filter(sql => sql.trim())) await connection.query(sql);
    await connection.execute('INSERT INTO operadores (codigo,nome,pin_hash,perfil) VALUES (?,?,?,?),(?,?,?,?)',
      ['OP001', 'Operador Demonstração', hashPin('1234'), 'OPERADOR', 'SUP001', 'Supervisora Demonstração', hashPin('5678'), 'SUPERVISOR']);
    await connection.query("INSERT INTO produtos (sku,descricao) VALUES ('BEB-001','Bebida demonstrativa'),('ALI-002','Alimento demonstrativo')");
    await connection.query("INSERT INTO lotes (codigo,produto_id,validade) VALUES ('LOT-001',1,DATE_ADD(UTC_DATE(), INTERVAL 90 DAY)),('LOT-002',2,DATE_SUB(UTC_DATE(), INTERVAL 1 DAY))");
    await connection.query("INSERT INTO enderecos (codigo,capacidade,ativo) VALUES ('A-01-01',2,1),('A-01-02',2,1),('B-01-01',1,1),('B-01-02',2,0)");
    await connection.query("INSERT INTO paletes (codigo,lote_id,endereco_id,quantidade) VALUES ('PAL-001',1,1,100),('PAL-002',1,3,80),('PAL-003',2,1,50)");
    console.log('Base didática reinicializada. Contas fictícias: OP001 / 1234 e SUP001 / 5678.');
  } finally {
    connection.release();
  }
}
await pool.end();
