import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
const base = `http://127.0.0.1:${process.env.PORT || 3000}`;
async function call(path, method = 'GET', body, token, key) {
  const response = await fetch(base + path, { method, headers: {
    'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(key ? { 'Idempotency-Key': key } : {})
  }, ...(body ? { body: JSON.stringify(body) } : {}) });
  return { status: response.status, data: response.status === 204 ? null : await response.json() };
}
assert.equal((await call('/health')).status, 200);
assert.equal((await call('/api/v1/paletes/PAL-001')).status, 401);
const login = await call('/api/v1/sessao', 'POST', { codigo: 'OP001', pin: '1234' });
assert.equal(login.status, 200);
const token = login.data.token;
const get = path => call(path, 'GET', undefined, token);
assert.equal((await get('/api/v1/paletes/PAL-001')).data.endereco, 'A-01-01', 'Reinicialize a base antes do teste');
const body = { cod_pal: 'PAL-001', tip_mov: 'T', end_dest: 'A-01-02' };
const key = randomUUID();
const moved = await call('/api/v1/movimentos', 'POST', body, token, key);
assert.equal(moved.status, 201);
const repeated = await call('/api/v1/movimentos', 'POST', body, token, key);
assert.equal(repeated.status, 200);
assert.equal(repeated.data.id, moved.data.id);
assert.equal((await call('/api/v1/movimentos', 'POST', { ...body, end_dest: 'B-01-01' }, token, key)).status, 409);
assert.equal((await call('/api/v1/movimentos', 'POST', { ...body, end_dest: 'B-01-01' }, token, randomUUID())).data.codigo, 'END_LOTADO');
assert.equal((await get('/api/v1/paletes/PAL-001')).data.endereco, 'A-01-02');
const expired = { cod_pal: 'PAL-003', tip_mov: 'T', end_dest: 'A-01-02' };
assert.equal((await call('/api/v1/movimentos', 'POST', expired, token, randomUUID())).data.codigo, 'LOT_VENCIDO');
const removal = { cod_pal: 'PAL-003', tip_mov: 'B', motivo: 'Teste de validade' };
assert.equal((await call('/api/v1/movimentos', 'POST', removal, token, randomUUID())).status, 403);
const supervisor = await call('/api/v1/sessao', 'POST', { codigo: 'SUP001', pin: '5678' });
assert.equal(supervisor.status, 200);
assert.equal((await call('/api/v1/movimentos', 'POST', removal, supervisor.data.token, randomUUID())).status, 201);
assert.equal((await get('/api/v1/paletes/PAL-003')).data.quantidade, 0);
assert.equal((await get('/api/v1/movimentos')).data.length, 1);
assert.equal((await call('/api/v1/movimentos', 'GET', undefined, supervisor.data.token)).data.length, 2);
assert.equal((await call('/api/v1/sessao', 'DELETE', undefined, token)).status, 204);
assert.equal((await get('/api/v1/paletes/PAL-001')).status, 401);
await call('/api/v1/sessao', 'DELETE', undefined, supervisor.data.token);
console.log('Integração HTTP/MySQL aprovada. Reinicialize a base para a próxima execução.');
